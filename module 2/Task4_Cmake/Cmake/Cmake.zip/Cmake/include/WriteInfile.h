#pragma once

void WriteToFile();
