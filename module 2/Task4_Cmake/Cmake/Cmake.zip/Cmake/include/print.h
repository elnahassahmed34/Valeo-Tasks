#pragma once

void PrintHello();
