#include "../include/print.h"
#include <iostream>

void PrintHello() {
    std::cout << "helloWorld" << std::endl;
}
